from django.conf.urls import url
from howdy import views

urlpatterns = [
    url(r'^$', views.HomePageView.as_view(), name='home'), # the URL has been named
    url(r'^about/$', views.AboutPageView.as_view(), name='about'), # Add this /about/ route
    url(r'^data/$', views.DataPageView.as_view(), name='data'),
]
